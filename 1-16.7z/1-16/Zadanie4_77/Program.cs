﻿using System;

namespace Zadanie4_77
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите число B:");
            int b = int.Parse(Console.ReadLine());
            int c = b / b;
            if (c < a)
            {
                int d = b * b * b * b * b;
                Console.WriteLine(d);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Число В, больше числа А!");
            }
        }
    }
}
