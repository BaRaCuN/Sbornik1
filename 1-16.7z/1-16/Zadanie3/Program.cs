﻿using System;

namespace Zadanie3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool B = false;
            bool A = true;
            Console.WriteLine(!A || !B || A);
            Console.WriteLine(B || !A && !B);
            Console.WriteLine(B && !(A && !B));
        }
    }
}
