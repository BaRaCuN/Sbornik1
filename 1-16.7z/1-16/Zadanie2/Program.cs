﻿
using System;

namespace Zadanie2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите трехзначное число: ");
            string input = Console.ReadLine();
            int number = 0;
            if (input.Length != 3 || !int.TryParse(input, out number))
            {
                Console.WriteLine("Введенное число не подходит под условие!");
                return;
            }
            Console.WriteLine("Число, полученное при перестановке второй и третьей цифры: {0}{2}{1}", input[0], input[1], input[2]);
            Console.ReadKey();
        }
    }
}