﻿using System;

namespace Zadanie5_47
{
    class Program
    {
        static void Main(string[] args)
        {
            int a1 = 1;
            int a2 = 2;
            int a3 = 3;
            int a4 = 4;
            int a5 = 5;
            int a6 = 6;

            int b = a1 * a2 * a3 * a4 * a5 * a6;
            Console.WriteLine(b);
        }
    }
}
