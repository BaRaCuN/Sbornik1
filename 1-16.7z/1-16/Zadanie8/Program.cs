﻿using System;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Столбцов: ");
            int x = int.Parse(Console.ReadLine());
            Console.Write("Строк: ");
            int y = int.Parse(Console.ReadLine());
            int[,] mas = new int[x, y];
            Console.WriteLine();

            Console.WriteLine("Заполни матрицу");

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    Console.Write("mas[" + i + "," + j + "]: ");
                    mas[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine();
            int maxval = 0;
            foreach (int a in mas)
            {
                maxval = maxval < a ? a : maxval;
            }
            Console.WriteLine("наибольшее число в этом двухмерном массиве : " + maxval);
        }
    }
}
