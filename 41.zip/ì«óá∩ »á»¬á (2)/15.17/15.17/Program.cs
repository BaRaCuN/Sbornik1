﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] arr_str = File.ReadAllLines("file.txt", Encoding.Default);
            foreach (string s in arr_str)
                Console.WriteLine(s);
        }
    }
}
