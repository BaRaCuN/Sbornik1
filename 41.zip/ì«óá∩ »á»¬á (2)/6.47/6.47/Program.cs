﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._47
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            int A = int.Parse(Console.ReadLine());

            Console.WriteLine("Верно ли, что сумма его цифр меньше a?");
            Console.WriteLine("Введите число a:");
            int a = int.Parse(Console.ReadLine());
            int s = 0;
            int n = 0;
            while (n > 0)
            {
                int k = A % 10;
                s = s + k;
                n = n / 10;
            }
            if (s > a)
            {
                Console.WriteLine("Сумма чисел больше а!");
            }
            {
                Console.WriteLine("Сумма чисел меньше а!");
            }

            Console.WriteLine("Верно ли, что произведение его цифр больше b?");
            Console.WriteLine("Введите число b:");
            int b = int.Parse(Console.ReadLine());
            int x = 1;
            while (A<0 && A > 0)
            {
                x = x * (n % 10);
                n = n / 10;
            }
            if (x >=b)
            {
                Console.WriteLine("Произведение чисел больше b!");
            }
            else
            {
                Console.WriteLine("Произведение чисел меньше b!");
            }

            Console.WriteLine("Верно ли, что его первая цифра превышает m?");
            Console.WriteLine("Введите число b:");
            int m = int.Parse(Console.ReadLine());
            int z = 0;
            while (m<0 && m > 0)
            {
                z = z + 1;
                Console.WriteLine(m % 10);
                m = m / 10;
            }
            Console.WriteLine($"Число {m} содержит {z} цифр");
        }
    }
}
