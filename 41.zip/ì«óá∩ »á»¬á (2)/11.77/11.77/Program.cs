﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._77
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            Console.WriteLine($"Самый дорогой: {Enumerable.Repeat(0, 50).Select(x => rnd.Next(1000000)).Max()}");
            Console.ReadKey();
        }
    }
}
