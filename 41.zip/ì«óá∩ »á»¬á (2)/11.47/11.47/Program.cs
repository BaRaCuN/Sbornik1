﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._47
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[] { -1, -23, -21, 23, -123, 231 };
            int count = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if ((i + 1) % 2 == 0)
                    continue;
                else if (array[i] < 0)
                {
                    Console.WriteLine(array[i] + " ");
                    count++;
                }
            }
            Console.WriteLine("\n" + count);
            Console.ReadLine();
        }
    }
}
