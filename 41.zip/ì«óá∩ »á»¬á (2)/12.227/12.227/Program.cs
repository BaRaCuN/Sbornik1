﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._227
{
    internal class Program
    {
        static void Main(string[] args)
            //12.218
        {
            int[] temp;
            const int n = 4, k = 6, r = 6, d = 4, l = 4;
            int[][] a = new int[n][];
            a[0] = new int[k] { 1, 2, 3, 4, 5, 6 };
            a[1] = new int[l] { 10, 20, 30, 40 };
            a[2] = new int[r] { 100, 200, 300, 400, 500, 600 };
            a[3] = new int[d] { 1000, 2000, 3000, 4000 };


            //Инвертируем массив
            for (int count = 0; count < a.Length / 2; count++)
            {
                temp = a[count];
                a[count] = a[a.Length - count - 1];
                a[a.Length - count - 1] = temp;
            }


            //Просто печатаем массив в консоль
            for (int i = 0; i < a[0].Length; i++)
                Console.Write(a[0][i] + " ");
            Console.WriteLine();
            // Вывести значения из второго массива, 
            for (int i = 0; i < a[1].Length; i++)
                Console.Write(a[1][i] + " ");
            Console.WriteLine();
            for (int i = 0; i < a[2].Length; i++)
                Console.Write(a[2][i] + " ");
            Console.WriteLine();
            // Вывести значения из второго массива, 
            for (int i = 0; i < a[3].Length; i++)
                Console.Write(a[3][i] + " ");
            Console.WriteLine();

            Console.ReadLine();
        }

    }
}
