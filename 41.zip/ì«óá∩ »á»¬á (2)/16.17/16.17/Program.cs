﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] massiv = new int[30];
            Random random = new Random();

            for (int i = 0; i < 30; i++)
            {
                massiv[i] = random.Next(0, 5);
                if (massiv[i] % 2 == 0)
                    Console.Write("{0} ", massiv[i]);
            }
            Console.ReadLine();
        }
    }
}
