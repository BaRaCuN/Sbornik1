﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //13.18
            Dictionary<string, string> countries = new Dictionary<string, string> {
                {"Кения","Африка"},
                {"Нидерланды","Европа"}, // Надеюсь, что станут чемпионами в этом году ^^
                {"Афганистан","Азия"},
                {"КНР","Азия"}  
                // по аналогии добавьте остальные
            };

            var result = countries.Where(kvp => kvp.Value == "Африка" || kvp.Value == "Азия");
            foreach (var kvp in result)
            {
                Console.WriteLine(kvp.Key);
            }
            Console.ReadKey(true);
        }
    }
}
