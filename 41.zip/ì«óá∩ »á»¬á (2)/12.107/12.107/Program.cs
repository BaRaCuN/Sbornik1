﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._107
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] mass = new int[22, 2];
            Random rand = new Random();
            int[] sum = new int[mass.GetLength(0)];
            int max = sum[0];
            int tempI = 0;

            Console.WriteLine("Исходный массив [{0},{1}]:", mass.GetLength(0), mass.GetLength(1));
            for (int i = 0; i < mass.GetLength(0); i++)
            {
                for (int j = 0; j < mass.GetLength(1); j++)
                {
                    mass[i, j] = rand.Next(10, 99);
                    Console.Write("{0} ", mass[i, j]);
                    sum[i] = mass[i, j];
                    if (max < sum[i]) { max = sum[i]; tempI = i; }
                }
                Console.WriteLine();
            }

            Console.WriteLine("Суммы по строкам: ");
            foreach (int n in sum)
                Console.Write("{0} ", n);

            Console.WriteLine("\nМаксимум равен {0}, строка {1} ", max, tempI);

            Console.ReadLine();
        }
    }
    }
}
