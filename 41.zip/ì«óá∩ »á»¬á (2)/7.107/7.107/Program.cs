﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7._107
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var b = new[] { 1.0, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var P = 3.2;
            var B = 7.8;
            var sum = 0;
            foreach (var t in b)
                if (t > P && t < B)
                    sum = sum + t;
            Console.WriteLine(sum);
        }
    }
}
