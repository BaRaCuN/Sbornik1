﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7._77
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            do
            {
                Console.Write("a = ");
                a = int.Parse(Console.ReadLine());
            }
            while (a != 0 && a != 8);

            var array = new[] { 1, 8, 2, 8, 3, 8, 4, 8, a };

            var count = 0;
            for (var i = 0; i < array.Length; i++)
            {
                if (array[i] == 8)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
            Console.ReadLine();
        }
    }
}
