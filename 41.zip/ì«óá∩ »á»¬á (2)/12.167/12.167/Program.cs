﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._167
{
    internal class Program
    {
        static readonly Random rnd = new Random();

        static int[,] CreateSquareMatrixWithRandomValues(int size, int maxValue)
        {
            var matrix = new int[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    matrix[i, j] = rnd.Next(maxValue);
                }
            }
            return matrix;
        }

        static void FancyPrint(int[,] matrix, int value)
        {
            int maxDigits = (int)Math.Ceiling(Math.Log10(matrix.Cast<int>().Max()));
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        Console.ForegroundColor = matrix[i, j] > value ? ConsoleColor.Green : ConsoleColor.Red;
                    }
                    Console.Write(matrix[i, j].ToString().PadRight(maxDigits + 1));
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
        }

        static int CalculteSum(int[,] matrix, int value)
        {
            if (matrix.GetLength(0) != matrix.GetLength(1))
            {
                throw new ArgumentException("Работаю только с квадратными матрицами!");
            }

            int sum = 0;

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                if (matrix[i, i] > value)
                {
                    sum += matrix[i, i];
                }
            }

            return sum;
        }

        static void Main()
        {
            int n = 100;
            var matrix = CreateSquareMatrixWithRandomValues(10, 40);
            var sum = CalculteSum(matrix, n);
            FancyPrint(matrix, n);
            Console.WriteLine();
            Console.WriteLine($"Сумма элементов главной диагонали матрицы, больших чем {n}, равна {sum}");
        }
    }
}
