﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._197
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var t = new[,] { { 1, 2, 3, 4 }, { 3, 4, 5, 6 }, { 5, 6, 7, 8 } };
            for (int i = 0; i < t.GetLength(0); i++)
            {
                for (int j = 0; j < t.GetLength(1); j++)
                    Console.Write("{0}\t", t[i, j]);
                Console.WriteLine();
            }
            Console.WriteLine(new string('-', 40));
            SwapColumns(t);
            for (int i = 0; i < t.GetLength(0); i++)
            {
                for (int j = 0; j < t.GetLength(1); j++)
                    Console.Write("{0}\t", t[i, j]);
                Console.WriteLine();
            }
        }
        static void SwapColumns(int[,] m)
        {
            for (int i = 0; i < m.GetLength(0); i++)
                for (int j = 0; j < m.GetLength(1); j += 2)
                {
                    var t = m[i, j];
                    m[i, j] = m[i, j + 1];
                    m[i, j + 1] = t;
                }
        }
    }
}
