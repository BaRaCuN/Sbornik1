﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._107
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите слово:");
            string text = Console.ReadLine();
            string str = "";

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == 'o' && i % 2 == 1)
                    str += text.Replace("o", "");

                else
                    str += text[i];
            }
            Console.WriteLine(str);
            Console.ReadKey();
        }
    }
}
