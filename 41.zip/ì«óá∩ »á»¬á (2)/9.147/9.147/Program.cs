﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _9._147
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var str = "asd1khjlb123kljblkjlkjh345678;kpooppoi";
            var result = Regex.Matches(str, @"\d+").Cast<Match>().OrderByDescending(x => x.Value.Length).FirstOrDefault()?.Length ?? -1;
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
