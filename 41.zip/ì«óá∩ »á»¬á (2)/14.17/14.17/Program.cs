﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var charsFromFile = File.ReadAllText("test.txt");
            var charsArray = charsFromFile.Split(' ');
            var stringResult = string.Join("", charsArray);
            Console.WriteLine("Result: " + stringResult);

            Console.ReadKey();
        }
    }
}
