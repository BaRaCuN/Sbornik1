﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._197
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[20] { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2, 1, 4, 3, 2, 4, 2, 4, 3, 4 };
            int count = 0, i = 0;
            while (i < arr.Length && arr[i] == 2)
            {
                count++;
                i++;
            }
            Console.WriteLine(count + " двоек");
        }
    }
}
