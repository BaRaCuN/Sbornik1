﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] mas = new int[] { -1, 2, 3, -1, -2 };
            for (int i = 0; i < mas.Length; i++)
                if (mas[i] == 2)
                {
                    if (i > 0) Console.Write(mas[i - 1]);
                    if (i < mas.Length - 1) Console.Write(mas[i + 1]);
                }
        }
    }
}
