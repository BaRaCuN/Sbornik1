﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17._17_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int n = 123423123;
            const char a = '1';
            const char b = '3';
            bool result =
                n.ToString().GroupBy(c => c).First(chars => chars.Key == a).Count()
                <
                n.ToString().GroupBy(c => c).First(chars => chars.Key == b).Count();
            Console.WriteLine(result);
        }
    }
}
