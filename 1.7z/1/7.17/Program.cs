﻿using System;

namespace Zadanie7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значение X1:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение Xm:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение n:");
            int d = int.Parse(Console.ReadLine());
            int c = 0;
            for (int i = a; a<=i && i<= b; i++)
            {
                if (i % d == 0)
                {
                    c += i;
                }
            }
            Console.WriteLine(c);
        }
    }
}
