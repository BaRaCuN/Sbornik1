﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13._47
{
    internal class Program
    {
        class Student
        {
            public string name;
            public double sheight;

            public Student(string name, double sHeight)
            {
                this.name = name;
                this.sheight = sHeight;
            }
        }
        static void Main(string[] args)
        {

            List<Student> listS = new List<Student>();
            //Добавление учеников
            listS.Add(new Student("Ivanov", 165.1));
            listS.Add(new Student("Petrov", 145.1));
            listS.Add(new Student("Sidorov", 150.3));

            // Шейк-сортировка
            static void ShakerSort(int[] listS)
            {
                int left = 0,
                    right = listS.Length - 1,
                    count = 0;

                while (left < right)
                {
                    for (int i = left; i < right; i++)
                    {
                        count++;
                        if (listS[i] > listS[i + 1])
                            Swap(listS, i, i + 1);
                    }
                    right--;

                    for (int i = right; i > left; i--)
                    {
                        count++;
                        if (listS[i - 1] > listS[i])
                            Swap(listS, i - 1, i);
                    }
                    left++;
                }
                static void Swap(int[] listS, int i, int j)
                {
                    int glass = listSt[i];
                    listS[i] = listSt[j];
                    listS[j] = glass;
                }
                static void WriteArray(int[] a)
                {
                    foreach (int i in a)
                        Console.Write("{0}|", i.ToString());
                    Console.WriteLine("\n\n\n");
                }
            }
        }
    }
}
