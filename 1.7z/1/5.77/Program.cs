﻿using System;

namespace Zadanie5_77
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = -1 * -1 + 2 * 2 - 3 * -3 + 4 * 4 - 5 * -5 + 6 * 6 - 7 * -7 + 8 * 8 - 9 * -9 + 10 * 10;
            Console.WriteLine(a);
        }
    }
}
