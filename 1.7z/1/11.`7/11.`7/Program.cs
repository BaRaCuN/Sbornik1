﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int [20];
            for (int i = 21; i > 1; i--)
                A[21 - i] = i;
            for(int a = 0; a<A.Length; a++ )
                Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
