﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._167
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string sample = "Напечатать все его слова в порядке неубывания их длин";
            string[] mas = sample.Split('.', ' ', ',');

            foreach (string str in mas.OrderBy(x => x.Length))
                Console.WriteLine(str);
            Console.ReadKey();
        }
    }
}
