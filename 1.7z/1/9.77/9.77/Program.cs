﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._77
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s = "qwerty";
            Console.WriteLine(Rev(s));
            Console.ReadKey();
        }

        static string Rev(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            string s2 = new string(arr);
            if (s == s2) return "YES";
            else return "NO";
        }
    }
}
