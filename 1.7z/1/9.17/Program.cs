﻿
using System;

namespace Zadanie9
{
    class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            int length = word.Length;
            if (word[0] == word[length - 1])
                Console.WriteLine("Верно");
            else Console.WriteLine("Не верно");
            Console.ReadKey();
        }
    }
}
