﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._77
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 0, b = 1;
            var k = 4181;
            int element;
            while (true)
            {
                element = a + b;
                if (element > k)
                {
                    Console.WriteLine("Число " + k + " не является числом Фибоначчи.");
                    break;
                }
                else if (element == k)
                {
                    Console.WriteLine("Число " + k + " является числом Фибоначчи.");
                    break;
                }
                a = b;
                b = element;
            }
            Console.ReadKey();
        }
    }
}
