﻿using System;

namespace Zadanie1_17
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();

                Console.WriteLine("1.√(x^2+x^2) \t        2.x1*x2+x1*x3+x2*x3 \t3.v*t+(a*t^2)/2 \n4.(m*v^2)/2+m*g*h \t5.1/r1+1/r2 \t        6.m*g*cosa \n7.2*п*R \t        8.b^2-4*a*c \t        9.Y*(m1*m2)/r^2 \n10.I^2*R \t        11.a*b*sinc \t        12.√(a^2+b^2-2*a*b*cosc) \n13.(a*d+b*c0/a*d \t14.√(1-sin^2*x) \t15.1/(a*x^2+b*x+c) \n16.(√(x+1))+√(x-1))/2√x\t17.|x|+|x+1| \t        18|1-|x||");
                int sw = int.Parse(Console.ReadLine());
                switch (sw)
                {
                    case 1:
                        Z1();
                        break;
                    case 2:
                        Z2();
                        break;
                    case 3:
                        Z3();
                        break;
                    case 4:
                        Z4();
                        break;
                    case 5:
                        Z5();
                        break;
                    case 6:
                        Z6();
                        break;
                    case 7:
                        Z7();
                        break;
                    case 8:
                        Z8();
                        break;
                    case 9:
                        Z9();
                        break;
                    case 10:
                        Z10();
                        break;
                    case 11:
                        Z11();
                        break;
                    case 12:
                        Z12();
                        break;
                    case 13:
                        Z13();
                        break;
                    case 14:
                        Z14();
                        break;
                    case 15:
                        Z15();
                        break;
                    case 16:
                        Z16();
                        break;
                    case 117:
                        Z17();
                        break;
                    case 18:
                        Z18();
                        break;

                }

                Console.ReadLine();
            }
        }
        public static void Z1()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            int c = Convert.ToInt32(Math.Sqrt(a * a + b * b));
            Console.WriteLine(c);
            Console.ReadKey();
        }
        public static void Z2()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(a*b+a*c+b*c);
            Console.WriteLine(c);
            Console.ReadKey();
        }
        public static void Z3()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int v = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int t = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32((v*t)+(a*t*t)/2);
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z4()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int v = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int g = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int h = int.Parse(Console.ReadLine());
            int z = Convert.ToInt32((m*v*v)/2+(m*g*h));
            Console.WriteLine(z);
            Console.ReadKey();
        }
        public static void Z5()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int R1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int R2 = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(1/R1+1/R2);
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z6()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int g = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(m*g*Math.Cos(a));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z7()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int R = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(2*Math.PI*R);
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z8()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(b*b-4*a*c);
            Console.WriteLine(c);
            Console.ReadKey();
        }
        public static void Z9()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int y = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int m1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int m2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int r = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(y*((m1*m2)/r*r));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z10()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int I = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int R = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(I*I*R);
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z11()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(a*b*Math.Sin(c));
            Console.WriteLine(c);
            Console.ReadKey();
        }
        public static void Z12()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(Math.Sqrt(a*a+b*b-2*a*b*Math.Cos(c)));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z13()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int d = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            int z = Convert.ToInt32((a*d+b*c)/(a*d));
            Console.WriteLine(z);
            Console.ReadKey();
        }
        public static void Z14()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int x = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(Math.Sqrt(1-Math.Sin(x)*Math.Sin(x)));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z15()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int c = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение А:");
            int x = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(1/(Math.Sqrt(a*x*x+b*x+c)));
            Console.WriteLine(c);
            Console.ReadKey();
        }
        public static void Z16()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int x = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32((Math.Sqrt(x+1)+Math.Sqrt(x-1)/(2*Math.Sqrt(x))));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z17()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int x = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(Math.Abs(x)+Math.Abs(x+1));
            Console.WriteLine(d);
            Console.ReadKey();
        }
        public static void Z18()
        {
            Console.Clear();
            Console.WriteLine("Введите значение А:");
            int x = int.Parse(Console.ReadLine());
            int d = Convert.ToInt32(Math.Abs(1-Math.Abs(x)));
            Console.WriteLine(d);
            Console.ReadKey();
        }
    }
}
