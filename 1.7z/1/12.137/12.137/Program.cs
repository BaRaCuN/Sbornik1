﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._137
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int n = 3, m = 3;
            int[,] A = new int[n, m];
            int max = A[0, 0], x = 0, y = 0;
            for (var j = 0; j < n; j++)
                for (var i = 0; i < m; i++)
                {
                    Console.WriteLine("Введите {0}-й элемент {1}-й сторки", i + 1, j + 1);
                    A[i, j] = int.Parse(Console.ReadLine());
                    if (A[i, j] > max)
                    {
                        max = A[i, j];
                        x = j + 1;
                        y = i + 1;
                    }
                }
            Console.WriteLine("Массив:");
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                    Console.Write(A[i, j] + " ");
                Console.WriteLine();
            }
            Console.WriteLine($"Максимальный элемент {max} находится в строке {x}, в столбце {y}");
        }
    }
}
