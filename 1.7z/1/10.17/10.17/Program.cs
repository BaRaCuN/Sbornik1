﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Factorial(int n)
            {
                if (n == 1) return 1;

                return n * Factorial(n - 1);
            }
            int factorial1 = Factorial(5);
            int factorial2 = Factorial(8);
            int factorial3 = Factorial(6);
            int factorial4 = Factorial(4);

            int a = (2 * factorial1 + 3 * factorial2) / (factorial3 * factorial4);
            Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
