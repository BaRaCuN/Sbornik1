﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._77
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] arr2 = { { 1, 2, 3 }, { 1, 3, 5 } };
            Console.WriteLine(arr2.Cast<int>().ToArray().Distinct().Count());
        }
    }
}
