﻿using System;
using System.Globalization;

namespace Zadanie6
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Введите вещественное число A: ");
                double a = double.Parse(Console.ReadLine() ?? "", NumberStyles.Any);
                Console.Write("Введите целое число N: ");
                int n = int.Parse(Console.ReadLine() ?? "", NumberStyles.Integer);
                if (n <= 0)
                    throw new ArgumentOutOfRangeException("N", "Ожидалось значение N больше нуля.");
                double sum = 0;
                for (int i = 0; i <= n; i++)
                    sum += Math.Pow(a, n);
                Console.WriteLine("Сумма ряда: {0}", sum);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
            Console.ReadKey();
        }
    }
}
