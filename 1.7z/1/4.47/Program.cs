﻿using System;

namespace Zadanie4_47
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сторону треугольника А:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите сторону треугольника В:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите сторону треугольника С:");
            int c = int.Parse(Console.ReadLine());
            if (a == b && a != c && b != c)
            {
                Console.WriteLine("Треугольник является равнобедренным!");
            }
            else
            {
                Console.WriteLine("Треугольник не является равнобедренным!");
            }
            if (a != b && a==c & b != c)
            {
                Console.WriteLine("Треугольник является равнобедренным!");
            }
            else
            {
                Console.WriteLine("Треугольник не является равнобедренным!");
            }
            if (a != b && a != c && b == c)
            {
                Console.WriteLine("Треугольник является равнобедренным!");
            }
            else
            {
                Console.WriteLine("Треугольник не является равнобедренным!");
            }
        }
    }
}
