﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._137
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int n = 10;
            int[] a = new int[n] { 1, 6, 7, -51, -10, -16, 71, 53, 11, -13 };
            int max = a[0];
            for (int i = 1; i < n; i++)
                if (a[0] > max) max = a[i + 1];
            Console.WriteLine("Максимальный элемент= " + max);

        }
    }
}
