﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._47
{
    internal class Program
    {
        static int MaxElement(int[] arr, uint size)
        {
            if (size > 1u)
                return Math.Max(arr[size - 1], MaxElement(arr, size - 1));
            return arr[0];
        }

        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 4, 5, 4, 3, 2, 1 };
            Console.WriteLine(MaxElement(arr, (uint)arr.Length));
            Console.ReadKey(true);
        }
    }
}
