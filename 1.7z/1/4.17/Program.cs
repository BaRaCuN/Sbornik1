﻿using System;

namespace Zadanie4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите площадь круга:"); //КРУГ
            int A = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите треугольника:"); //ТРЕУГОЛНИК
            int B = int.Parse(Console.ReadLine());
            if (A / B <= 0.604)
            {
                Console.WriteLine("Мы можем уместить круг в треугольник!");
            }
            else
            {
                Console.WriteLine("Мы не можем уместить круг в треугольник!");
            }
            if (B / A <= 0.414)
            {
                Console.WriteLine("Мы можем уместить треугольник в круг!");
            }
            else
            {
                Console.WriteLine("Мы не можем уместить треугольник в круг!");
            }
        }
    }
}
