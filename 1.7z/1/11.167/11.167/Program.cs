﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._167
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 33;

            int[] mass = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 23, 52, 83, 106, 153, 607, 508, 1364, 1523, 5034, 6046, 2507 };
            int[] massx = new int[mass.Length * 2];

            for (int n = 0; n < mass.Length; n++)
            {
                massx[n] = mass[n];
            }
            int b = 0;

            for (int i = 0; i < mass.Length; i++)
            {

                if
                (((mass[i]) % 10 == 5) |
                ((((mass[i]) / 50) % 2 == 1) & (((mass[i]) % 50) < 10)) |
                ((((mass[i]) / 500) % 2 == 1) & (((mass[i]) % 500) < 100)))

                { massx[i + b] = mass[i]; massx[i + b + 1] = a; b++; }
                else { massx[i + b] = mass[i]; }


                Console.WriteLine(massx[i + b]);
            }
        }
    }
}
