﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var nums = new int[2, 3] { { 0, 1, 2 }, { 3, 4, 5 } };
            var indices = GetIndexesOfMinimumElement(nums);
            var i = indices.Item1;
            var j = indices.Item2;

            Console.WriteLine($"Минимальный элемент массива: {nums[i, j]}. i = {i}, j = {j}");
        }

        static (int, int) GetIndexesOfMinimumElement(int[,] array)
        {
            var minElement = array[0, 0];
            var result = (0, 0);

            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (minElement > array[i, j])
                    {
                        minElement = array[i, j];

                        result = (i, j);
                    }
                }
            }

            return result;
        }
    }
}
