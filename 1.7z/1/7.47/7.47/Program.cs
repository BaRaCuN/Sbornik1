﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7._47
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] masses = new int[10] { 30, 40, 20, 105, 20, 100, 130, 60, 80, 110 };

            int[] massFat = (from mass in masses where mass >= 100 select mass).ToArray();
            int[] massThin = masses.Except(massFat).ToArray();

            Console.WriteLine("Среднее значение массы толстых людей: {0}", massFat.Average());
            Console.WriteLine("Среднее значение массы остальных людей: {0}", massThin.Average());
            Console.ReadKey();
        }
    }
}
