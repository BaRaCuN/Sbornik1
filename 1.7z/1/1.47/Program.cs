﻿using System;

namespace Zadanie1_17
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 4.8;
            double b = 3.9;
            double c = 4.8;
            double d = 1.7;
            double e = Math.Sqrt((b - a) * (b - a) + (d - c) * (d - c));
            Console.WriteLine(e);
            Console.ReadLine();
        }
    }
}
