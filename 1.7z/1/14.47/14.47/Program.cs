﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14._47
{
    class Stack
    {
        char[] stck;
        int tos;
        //Параметрический конструктор класса Stack
        public Stack(int size)
        {
            stck = new char[size];
            tos = 0;
        }
        //Метод помещает в неполный стек элемент
        public void push(char ch)
        {
            if (tos == stck.Length)
            {
                Console.WriteLine("Стек заполнен.");
                return;
            }
            stck[tos] = ch;
            tos++;

        }
        //Метод отдаёт из непустого стека элемент
        public char pop()
        {
            if (tos == 0)
            {
                Console.WriteLine("Стек пуст.");
                return (char)0;
            }
            tos--;
            return stck[tos];
        }
        //Метод показывает общий объём стека
        public int volume()
        {
            return stck.Length;
        }
        //Метод показывает текущий объём стека
        public int kol()
        {
            return tos;
        }
        //Метод возвращает значение true, если стек полон
        public bool empty()
        {
            return tos == stck.Length;
        }
        //Метод возвращает значение true, если стек пуст
        public bool full()
        {
            return tos == 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Stack stck1 = new Stack(10);
            int i;
            char ch;
            Console.WriteLine("Программа демонстрирует работу со стеком.\n");
            Console.WriteLine("Текущее кол-во элементов в стеке: " + stck1.kol());
            Console.WriteLine("Заполняем стек.");
            for (i = 0; !stck1.empty(); i++)
            {
                stck1.push((char)('A' + i));
                Console.WriteLine("Текущее кол-во элементов в стеке: " + stck1.kol());
            }
            Console.WriteLine("Содержимое стека:");
            for (i = 0; !stck1.full(); i++)
            {
                ch = stck1.pop();
                Console.Write(ch);
            }
            Console.WriteLine("\nМаксимальный объём стека: " + stck1.volume());
            Console.ReadLine();
        }
    }
}
