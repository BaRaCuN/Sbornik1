﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._257
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int row = 0;
            bool yslovie = true;
            Console.WriteLine("Введите количество столбцов");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите количество строк");
            int m = Convert.ToInt32(Console.ReadLine());
            int[,] massiv = new int[m, n]; //объявляем массив
            Random rnd = new Random(); //функция рандом
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    massiv[i, j] = rnd.Next(0, 2); //с помощью рандома присваиваем элементы заданный диапазон
                    Console.Write(massiv[i, j] + "\t");
                    if (massiv[i, j] == row)
                    {
                        yslovie = true;
                    }
                }
                Console.WriteLine();
            }

            int[,] matrix = new int[m - 1, n];
            if (yslovie == true)
            {
                for (i = 0; i < matrix.GetLength(0); i++)
                {
                    if (i != row)
                    {
                        for (j = 0; j < matrix.GetLength(1); j++)
                        {
                            matrix[i, j] = massiv[i, j];
                            continue;
                        }
                    }
                    else
                    {
                        for (j = 0; j < matrix.GetLength(1); j++)
                        {
                            matrix[row, j] = massiv[i + 1, j];
                            continue;
                        }
                        row++;
                    }
                }
            }




            Console.WriteLine("Массив:"); // выводим массив

            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    Console.Write(matrix[i, j] + "\t");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
    }
}
