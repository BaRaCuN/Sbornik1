﻿using System;

namespace Zadanie6_107
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значение м:");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение н:");
            int n = int.Parse(Console.ReadLine());

            int c = m * n;

            for (int i = m; m <= n && n <= c; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
