﻿using System;

namespace Zadanie4_107
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите порядковый номер месяца:");
            int a = int.Parse(Console.ReadLine());
            if(a ==2)
            {
                Console.WriteLine("Год високосный? 1-да и 0-нет");
                int b = int.Parse(Console.ReadLine());
                if (b == 1)
                {
                    Console.WriteLine("В этом месяце 29 дней!");
                }
                else if(b == 0)
                {
                    Console.WriteLine("В этом месяце 28 дней!");
                }
            }
            if (a == 4 && a == 6 && a == 9 && a == 11)
            {
                Console.WriteLine("В этом месяце 30 дней!");
            }
            else
            {
                Console.WriteLine("В этом месяце 31 день!");
            }
        }
    }
}
