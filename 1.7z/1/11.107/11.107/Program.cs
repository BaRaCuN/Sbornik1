﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._107
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] mas = new int[] { 20, 124,12314,114,1142,11,2411,41124,1,41,41,41,4,14,12,412,412,312,3141 };
            int a = mas.Max();
            Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
