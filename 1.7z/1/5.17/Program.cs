﻿using System;

namespace Zadanie5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 4;
            int b = 28;
            
            for (int i=4; i<=b; i++)
            {
                double t = i + 2;
                double y = 2 * t * t + 5.5 * t - 2;
                Console.WriteLine(y);
            }
        }
    }
}
