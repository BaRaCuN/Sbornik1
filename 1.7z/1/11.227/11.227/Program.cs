﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._227
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            //2 - солнечная
            //1 - дожди
            //0 - снег
            int[] arr = new int[20] { 1, 2, 0, 2, 2, 2,2, 2, 2, 2, 2, 2, 1, 2, 0, 2, 2, 2, 1, 1 };
            int snow = 0, i = 0;
            while (i < arr.Length && arr[i] == 0)
            {
                snow++;
                i++;
            }
            int rain = 0, i = 0;
            while (i < arr.Length && arr[i] == 1)
            {
                rain++;
                i++;
            }
            Console.WriteLine(snow + " столько было снежной погоды");
            Console.WriteLine(rain + " столько было дождей");
        }
    }
}
